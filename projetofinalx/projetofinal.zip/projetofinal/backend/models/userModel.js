const conexao = require("../structure/conection");

class UserModel {

    executaQuery(sql, parametros = "") {
        return new Promise((resolve, reject) => {
            conexao.query(sql, parametros, (error, resposta) => {
                if (error) {
                    return reject(error);
                }

                return resolve(resposta);
            });
        });
    }
    listar() {
        const sql = "SELECT * FROM users";
        return this.executaQuery(sql);
    }
    criar(novoUser) {
        const sql = "INSERT INTO users SET ?";
        return this.executaQuery(sql, [novoUser]);
    }
    atualizar(dadosAtualizados, userId) {
        const sql = "UPDATE users SET ? WHERE usuario_id = ?";
        return this.executaQuery(sql, [dadosAtualizados, userId]);
    }
    delete(userId) {
        const sql = "DELETE FROM users WHERE usuario_id = ?";
        return this.executaQuery(sql, [userId]);
    }
}

module.exports = new UserModel();