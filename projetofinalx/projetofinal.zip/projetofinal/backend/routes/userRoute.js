const { Router } = require(`express`);
const router = Router();
const userController = require("../controllers/userController");

router.get("/user", (req,res) => {
   userController
   .listar()
   .then((user) => res.status(200).json(user))
   .catch((error) => {
       console.log(error);
       res.status(400).json({ message: error.message });
   })
});

router.post("/user", (req,res) => {
    const novoUser = req.body;
    userController
    .criar(novoUser)
    .then((userCriado) => res.status(201).json(userCriado))
    .catch((error) => {
        console.log(error);
        res.status(400).json({ message: error.message });
    });
});

router.put("/user/:id", (req,res) => {
    const {id} = req.params;
    const attUser = req.body;
    userController
    .alterar(attUser, id)
    .then((userAlterado) => res.status(200).json(userAlterado))
    .catch((error) => {
        console.log(error);
        res.status(400).json({ message: error.message });
    });
});

router.delete("/user/:id", (req,res) => {
    const {id} = req.params;
    userController
    .deletar(id)
    .then((userDeletado) => res.status(200).json(userDeletado))
    .catch((error) => {
        console.log(error);
        res.status(400).json({ message: error.message });
    });
});


module.exports = router;
