const roomModel = require("../models/roomModel");
const userModel = require("../models/userModel");

class userController {
    listar(){
        return userModel.listar();	
    }
    criar(novoUser){
        return userModel.criar(novoUser);	
    }
    alterar(dadosAtualizados,id){
        return userModel.atualizar(dadosAtualizados,id);	
    }
    deletar(id){
        return userModel.delete(id);	
    }
}
module.exports = new userController();